<?php
namespace OCA\GenerateExternalAccount\Controller;

use OCP\IRequest;
use OCP\AppFramework\Http\TemplateResponse;
use OCP\AppFramework\Controller;
use OCP\IConfig;
use OCP\AppFramework\Http\DataResponse;
use OCA\GenerateExternalAccount\AppInfo\AuthenticationClient;

class SettingsController extends Controller {
    private $config;

    public function __construct($AppName, IRequest $request, IConfig $config) {
        parent::__construct($AppName, $request);
        $this->config = $config;
    }

    /**
     * @NoAdminRequired
     */
    public function index() {
        $params = [
            'bmUrl' => $this->config->getAppValue('generateexternalaccount', 'bmUrl', ''),
            'bmToken' => $this->config->getAppValue('generateexternalaccount', 'bmToken', ''),
            'bmUser' => $this->config->getAppValue('generateexternalaccount', 'bmUser', '')
        ];

        return new TemplateResponse('generateexternalaccount', 'settings', $params);
    }

    /**
     * @NoAdminRequired
     * @NoCSRFRequired
     */
    public function setSettings($bmUrl, $bmToken, $bmUser) {
        $this->config->setAppValue('generateexternalaccount', 'bmUrl', $bmUrl);
        $this->config->setAppValue('generateexternalaccount', 'bmToken', $bmToken);
        $this->config->setAppValue('generateexternalaccount', 'bmUser', $bmUser);
        return new DataResponse(['status' => 'success']);
    }

    /**
     * @NoAdminRequired
     * @NoCSRFRequired
     */
    public function testConnection() {
        $bmUrl = $this->request->getParam('bmUrl');
        $bmToken = $this->request->getParam('bmToken');
        $bmUser = $this->request->getParam('bmUser');

        $authClient = new AuthenticationClient($bmUrl, null);
        $loginResponse = $authClient->login($bmUser, $bmToken, 'bm-php-client', true);

        if (!$loginResponse || $loginResponse->status === "Bad") {
            return new DataResponse(['status' => 'error', 'message' => "wrong credentials, please check your configuration."]);
        }

        return new DataResponse(['status' => 'success']);
    }
}