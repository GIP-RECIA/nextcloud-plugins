<?php

declare(strict_types=1);

namespace OCA\GenerateExternalAccount\AppInfo;

/**
 * GobalEnv
 */
class GlobalEnv {

    public static $curlOptions =  array(
        CURL_HTTP_VERSION_1_1 => TRUE,
        CURLOPT_RETURNTRANSFER => TRUE,
        CURLOPT_ENCODING  => "deflate",
        CURLOPT_MAXREDIRS => 5,
        CURLOPT_FOLLOWLOCATION => TRUE,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => TRUE,
        CURLOPT_USERAGENT => "BlueMind PHP Client"
    );
}
