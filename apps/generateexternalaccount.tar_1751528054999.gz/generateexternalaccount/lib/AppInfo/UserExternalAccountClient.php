<?php

declare(strict_types=1);

namespace OCA\GenerateExternalAccount\AppInfo;

/**
 * Implementation of net.bluemind.user.api.IUserExternalAccount.
 */

class UserExternalAccountClient {

    protected $base;
    protected $sid;
    protected $domain;
    protected $uid;

    /*
    * Constructor.
    *
    * @param base
    * @param sid
    * @param domain
    * @param uid
    *
    */
    public function __construct($base, $sid , $domain, $uid) {
        $this->sid = $sid;
        $this->base = $base."/api/users/{domain}/{uid}/accounts";
        $this->domain = $domain;
        $this->base = str_replace("{domain}", urlencode($domain), $this->base);
        $this->uid = $uid;
        $this->base = str_replace("{uid}", urlencode($uid), $this->base);
    }

    /*
    * @param system
    * @return
    */
    public function get( $system  ) {
        $postUri = "/{system}";
        $method = "GET";

        $postUri = str_replace("{system}", urlencode($system), $postUri);

        $url = $this->base.$postUri;

        $queryParam = array();

        $body = null;
        return $this->execute($url, $queryParam, $body, $method);
    }

    /*
    * @param system
    * @param account
    * @return
    */
    public function create( $system ,  $account  ) {
        $postUri = "/{system}";
        $method = "PUT";

        $postUri = str_replace("{system}", urlencode($system), $postUri);

        $url = $this->base.$postUri;

        $queryParam = array();

        $body = null;
        $body = $account;
        return $this->execute($url, $queryParam, $body, $method);
    }


    /*
    * Execute the request
    *
    * @param url
    * @param data
    * @param body
    */
    private function execute($url, $queryParam, $body, $method) {

        $curl = curl_init();

        $headers = array();
        array_push($headers, 'X-BM-ApiKey: '.$this->sid);

        if (sizeof($queryParam) > 0) {
            $url .= '?'.http_build_query($queryParam);
        }

        curl_setopt_array($curl, GlobalEnv::$curlOptions + array(
            CURLOPT_URL => $url,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_CUSTOMREQUEST => $method)
        );

        if ($method == 'POST') {
            curl_setopt($curl, CURLOPT_POST, TRUE);
            curl_setopt($curl, CURLOPT_POSTFIELDS, array());
        }

        if (is_resource($body)) {
            if ($method == 'PUT') {
                curl_setopt($curl, CURLOPT_PUT, TRUE);
            }
            $size = fstat($body)['size'];
            curl_setopt($curl, CURLOPT_INFILE, $body);
            curl_setopt($curl, CURLOPT_INFILESIZE, $size);
        } elseif(!is_null($body)) {
            if (is_object($body) && method_exists($body, 'serialize')) {
                $body = $body->serialize();
            } else if (is_object($body)) {
                $body = json_encode($body);
            } else if (is_array($body)) {
                $body = json_encode($body);
            } else if (is_string($body)) {
                $body = json_encode($body);
            }
            $size = strlen($body);
            array_push($headers, 'Content-Type: application/json');
            array_push($headers, 'Content-Length: '.$size);
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $body);
        }

        $resp = curl_exec($curl);
        if ($resp === false) {
            throw new \Exception(curl_error($curl));
        } 
        curl_close($curl);
        if (!$resp) {
            return;
        }
        $js = json_decode($resp);
        if ($js === NULL) {
            return $resp;
        }
        if (isset($js->errorCode)) {
            throw new \Exception($js->errorCode . ': ' . (isset($js->message) ? ' : ' . $js->message : ''));
        }
        return $js;
    }
}
