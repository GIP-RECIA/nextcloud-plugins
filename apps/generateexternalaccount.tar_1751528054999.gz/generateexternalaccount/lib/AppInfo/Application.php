<?php

declare(strict_types=1);

namespace OCA\GenerateExternalAccount\AppInfo;

use OC\Authentication\Token\IToken;
use OC\Authentication\Token\PublicKeyTokenProvider;
use OC\Security\SecureRandom;
use OC\User\Session;
use OCA\Settings\Controller\AuthSettingsController;
use OCP\AppFramework\App;
use OCP\AppFramework\Bootstrap\IBootContext;
use OCP\AppFramework\Bootstrap\IBootstrap;
use OCP\AppFramework\Bootstrap\IRegistrationContext;
use OCP\EventDispatcher\IEventDispatcher;
use OCP\IUser;
use OCP\Server;
use OCP\User\Events\UserLoggedInEvent;

use OC\Authentication\Token\IProvider;
use OC\Authentication\Token\RemoteWipe;
use OCP\Activity\IManager;
use OCP\IRequest;
use OCP\ISession;
use OCP\IUserSession;
use OCP\Security\ISecureRandom;
use Psr\Log\LoggerInterface;

use OCP\IContainer;
use OCP\IConfig;

use Exception;


class Application extends App implements IBootstrap {
	public const APP_ID = 'generateexternalaccount';

	/** @psalm-suppress PossiblyUnusedMethod */
	public function __construct() {
		parent::__construct(self::APP_ID);
		/* @var IEventDispatcher $dispatcher */
		$dispatcher = $this->getContainer()->query(IEventDispatcher::class);
		$dispatcher->addListener(UserLoggedInEvent::class, function(UserLoggedInEvent $event) {
			$logger = Server::get(LoggerInterface::class);

			// Retrieve Bluemind configurations
			$container = $this->getContainer();
			$container->registerService('Config', function(IContainer $c) {
				return $c->query(IConfig::class);
			});
			
			$bmUrl = $this->getBmUrl();
			$bmToken = $this->getBmToken();
			$bmUser = $this->getBmUser();

			if(
				(is_null($bmUrl) || trim($bmUrl) == '')
				&& (is_null($bmToken) || trim($bmToken) == '')
				&& (is_null($bmUser) || trim($bmUser) == '')
			) {
				$logger->error(
					'Bluemind credentials not configured'
				);
				return;
			}

			// Instanciate classes
			$request = Server::get(IRequest::class);
			$session = Server::get(Session::class);
			$authSettingsController = Server::get(AuthSettingsController::class);

			// Get user informations
			try {
				$userUID = $event->getUser()->getUID();
				$userDomain = explode("@", $userUID)[1] ?? null;
			} catch (Exception $e) {
				$logger->error(
					'An error occurred when attempt to retrieve user uid and domain',
					['exception' => $e]
				);
				return;
			}

			if (!is_null($userDomain)) {
				// Connect to bm
				$authClient = new AuthenticationClient($bmUrl, null);
				$loginResponse = $authClient->login($bmUser, $bmToken, 'bm-php-client');

				if ($loginResponse->status == "Bad") {
					$logger->error(
						'An error occurred when attempt to connect to Bluemind API',
						['exception' => $loginResponse->message]
					);
					return;
				}

				// Retrieve bm user domain
				$domainClient = new DomainsClient($bmUrl, $loginResponse->authKey);
				$domain = $domainClient->findByNameOrAliases($userDomain);

				if (is_null($domain)) {
					$logger->error(
						'No Bluemind domain found'
					);
					return;
				}

				// Retrieve bm user UID
				$userClient = new UserClient($bmUrl, $loginResponse->authKey, $domain->uid);
				$user = $userClient->byEmail($userUID);

				if (is_null($user)) {
					$logger->error(
						'No Bluemind user found'
					);
					return;
				}

				// Retrieve bm user external account
				$userExternalAccountClient = new UserExternalAccountClient($bmUrl, $loginResponse->authKey, $domain->uid, $user->uid);
				$userExternalAccount = $userExternalAccountClient->get("Nextcloud");

				if (empty($userExternalAccount)) {
					// Check if an external account is already being created
					$lockFile = sys_get_temp_dir() . '/bm_external_account_' . $userUID . '.lock';
					if (file_exists($lockFile)) {
						// Check if the file is older than one hour
						$fileTime = filemtime($lockFile);
						if (time() - $fileTime > 3600) {
							unlink($lockFile);
							$logger->info('Lock file has been deleted because it was older than one hour');
						} else {
							$logger->info('An external account is already being created for this user');
							return;
						}
					}

					// Create lock file
					file_put_contents($lockFile, time());

					try {
						// Create session token
						$session->createSessionToken($request, $userUID, $userUID);
						// Create app token for bm
						$appToken = $authSettingsController->create("NC_bluemind");
					} catch (Exception $e) {
						$logger->error(
							'An error occurred when attempt to generate app token',
							['exception' => $e]
						);
						return;
					}

					$bmAppAccess = $appToken->getData();

					if(!empty($bmAppAccess)) {
						$credentials = array(
							"login" => $bmAppAccess["loginName"],
							"credentials" => $bmAppAccess["token"]
						);
						// Create nextcloud external account
						$bmExternalAccount = $userExternalAccountClient->create("Nextcloud", $credentials);

						if(!is_null($bmExternalAccount)) {
							$logger->error(
								'An error occurred when attempt to create external account',
								['exception' => $bmExternalAccount]
							);
							// Remove lock file
							if (file_exists($lockFile)) {
								unlink($lockFile);
							}

							return;
						}
					}
				}
			}
		});
	}

	private function getBmUrl() {
        return $this->getContainer()->query('Config')->getAppValue('generateexternalaccount', 'bmUrl', '');
    }

    private function getBmToken() {
        return $this->getContainer()->query('Config')->getAppValue('generateexternalaccount', 'bmToken', '');
    }

    private function getBmUser() {
        return $this->getContainer()->query('Config')->getAppValue('generateexternalaccount', 'bmUser', '');
    }

	public function register(IRegistrationContext $context): void {
	}

	public function boot(IBootContext $context): void {
	}
}
