<?php
return [
    'routes' => [
        ['name' => 'settings#index', 'url' => '/settings', 'verb' => 'GET'],
        ['name' => 'settings#setSettings', 'url' => '/settings', 'verb' => 'POST'],
        ['name' => 'settings#testConnection', 'url' => '/test-connection', 'verb' => 'POST']
    ]
];