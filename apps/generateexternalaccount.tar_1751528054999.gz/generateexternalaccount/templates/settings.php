<?php
style('generateexternalaccount', 'generateexternalaccount-settings');
script('generateexternalaccount', 'generateexternalaccount-settings');
?>

<div id="generateexternalaccount" class="section">
    <h2><?php p($l10n->t('Generate external account')); ?></h2>
    <p class="settings-section__desc"><?php p($l10n->t('Configure Bluemind API connection settings')); ?></p>
    <form id="generateexternalaccount-settings-form">
        <div class="system-tag-form__group">
            <label for="bmUrl"><?php p($l10n->t('BM URL')); ?></label>
            <input type="text" id="bmUrl" name="bmUrl" value="<?php p($_['bmUrl']); ?>" />
        </div>

        <div class="system-tag-form__group">
            <label for="bmUrl"><?php p($l10n->t('BM Token')); ?></label>
            <input type="text" id="bmToken" name="bmToken" value="<?php p($_['bmToken']); ?>" />
        </div>

        <div class="system-tag-form__group">
            <label for="bmUrl"><?php p($l10n->t('BM User')); ?></label>
            <input type="text" id="bmUser" name="bmUser" value="<?php p($_['bmUser']); ?>" />
        </div>

        <div class="form-group">
            <button type="button" id="test-connection" class="button"><?php p($l10n->t('Test Connection')); ?></button>
        </div>

        <input type="submit" value="<?php p($l10n->t('Save')); ?>" class="button primary nc_bluemind"/>
    </form>
</div>