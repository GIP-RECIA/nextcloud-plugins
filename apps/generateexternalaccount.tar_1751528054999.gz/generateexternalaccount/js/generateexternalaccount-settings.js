document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('generateexternalaccount-settings-form');
    form.addEventListener('submit', function(event) {
        event.preventDefault();

        const bmUrl = document.getElementById('bmUrl').value;
        const bmToken = document.getElementById('bmToken').value;
        const bmUser = document.getElementById('bmUser').value;

        fetch(OC.generateUrl('/apps/generateexternalaccount/settings'), {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'RequestToken': OC.requestToken
            },
            body: JSON.stringify({ bmUrl, bmToken, bmUser })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                OC.Notification.show(t('generateexternalaccount', 'Settings saved successfully'));
            } else {
                OC.Notification.show(t('generateexternalaccount', 'Failed to save settings'));
            }
        });
    });

    const testConnectionButton = document.getElementById('test-connection');
    testConnectionButton.addEventListener('click', function() {
        const bmUrl = document.getElementById('bmUrl').value;
        const bmToken = document.getElementById('bmToken').value;
        const bmUser = document.getElementById('bmUser').value;

        fetch(OC.generateUrl('/apps/generateexternalaccount/test-connection'), {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'RequestToken': OC.requestToken
            },
            body: JSON.stringify({ bmUrl, bmToken, bmUser })
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                OC.Notification.show(t('generateexternalaccount', 'Connection successful'));
            } else {
                OC.Notification.show(t('generateexternalaccount', 'Connection failed: ' + data.message));
            }
        });
    });
});