# Generate External Account

## Configuration

Une fois l'application installée et activée, se rendre dans les paramètres administrateur puis dans l'ongelt `Génération de compte externe`.
Configurer les paramètres suivants :
* `URL Bluemind` : URL d'accès au Bluemind souhaité
* `Token de l'utilisateur Bluemind` : token de connexion API de l'utilisateur Bluemind
* `Identifiant de l'utilisateur` : identifiant de connexion API de l'utilisateur Bluemind

`Note: si un de ces paramètres n'est pas configuré, l'application ne fera aucune action et affichera le message suivant dans les logs Nextcloud : Bluemind credentials not configured.`

Sauvegarder la configuration.

## Fonctionnement

L'application détecte la connexion d'un utilisateur.

Elle va récupérer son UID et détertimer son domain en fonction de l'UID.

Exemple : 
* UID = factorfx@factorfx.org
* Domain = factorfx.org

L'application va récupérer les informations BM de l'utilisateur via les appels API.

Elle va vérifier si un compte externe Nextcloud existe déjà.

Si oui, l'application s'arrête là.

Si non, elle va générer un token d'application côté Nextcloud et créer un compte externe avec ce token côté BM.

## Gestion des logs

Voici une liste exhaustive des retour d'erreur possible de l'application :
- `Bluemind credentials not configured` : l'application n'est pas correctement configurée
- `An error occurred when attempt to retrieve user uid and domain` + message exception : erreur lors de la récupérétion des informations utilisateur côté Nextcloud
- `An error occurred when attempt to connect to Bluemind API` + message retour API BM : erreur de connexion API 
- `No Bluemind domain found` : pas de domaine correspondant du côté BM
- `No Bluemind user found` : pas d'utilisateur correspondant du côté BM
- `An error occurred when attempt to generate app token` + message exception : erreur lors de la génération du token d'application côté Nextcloud

`Note: à la moindre erreur rencontrée, l'application ne finira pas son process. Ne génère aucun gêne pour l'utilisateur.`

Les logs se génère dans le fichier `nextcloud.log`.